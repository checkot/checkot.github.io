import json
import urllib.parse
import re
import time
import os
import sys
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

# Prepare HTML bundle for Chromium test
repo_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
index_path = os.path.join(repo_dir, 'index.html')

with open(index_path, 'r', encoding='utf-8') as f:
    html = f.read()

def repl_css(m):
    href = m.group(1)
    try:
        with open(os.path.join(repo_dir, href), 'r', encoding='utf-8') as cf:
            return f'<style>/* {href} */\n{cf.read()}\n</style>'
    except Exception as e:
        return m.group(0)

html = re.sub(r'<link rel="stylesheet" href="([^"]+)">', repl_css, html)

def repl_js(m):
    src = m.group(1)
    try:
        with open(os.path.join(repo_dir, src), 'r', encoding='utf-8') as jf:
            return f'<script>/* {src} */\n{jf.read()}\n</script>'
    except Exception as e:
        return m.group(0)

html = re.sub(r'<script src="([^"]+)"></script>', repl_js, html)

with open(os.path.join(repo_dir, 'areas.json')) as f: areas = json.load(f)
with open(os.path.join(repo_dir, 'notices.json')) as f: notices = json.load(f)
with open(os.path.join(repo_dir, 'team.json')) as f: team = json.load(f)
with open(os.path.join(repo_dir, 'absent.json')) as f: absent = json.load(f)
with open(os.path.join(repo_dir, 'data/2026-10.json')) as f: oct_full = json.load(f)

with open(os.path.join(repo_dir, 'tests/benchmark_baseline.json')) as f: baseline = json.load(f)
b_ids = set()
for m, emps in baseline['months'].items():
    for e in emps: b_ids.add(e['id'])

oct_sample = dict(oct_full)
oct_sample['employees'] = [e for e in oct_full['employees'] if e['id'] in b_ids or oct_full['employees'].index(e) < 30]

mock_data = {
    'areas.json': areas,
    'notices.json': notices,
    'team.json': team,
    'absent.json': absent,
    'data/2026-10.json': oct_sample,
    'data/latest.json': oct_sample
}

mock_script = f'''<script>
window.mockFetchData = {json.dumps(mock_data)};
window.fetch = async (url) => {{
  const clean = String(url).split('?')[0].replace('https://checkot.github.io/', '').replace(/^https?:\\/\\/[^\\/]+\\//, '');
  if (window.mockFetchData[clean]) {{
    const d = window.mockFetchData[clean];
    return {{ ok: true, status: 200, json: async () => d, text: async () => JSON.stringify(d) }};
  }}
  return {{ ok: false, status: 404 }};
}};
</script>'''

html = html.replace('</head>', mock_script + '\n</head>')

# Replace logo img src and google fonts link in HTML to prevent offline network warnings
html = html.replace('<img class="logo" src="https://checkot.github.io/icon.png"', '<img class="logo" src="data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'32\' height=\'32\'></svg>"')
html = re.sub(r'<link[^>]+fonts\.googleapis\.com[^>]+>', '', html)

base_data_url = 'data:text/html;charset=utf-8,' + urllib.parse.quote(html)

options = Options()
options.add_argument('--headless=new')
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')
options.add_argument('--disable-gpu')
options.add_argument('--window-size=412,915')
options.set_capability('goog:loggingPrefs', {'browser': 'ALL'})

driver = webdriver.Chrome(options=options)

screenshots_dir = os.path.join(repo_dir, 'screenshots')
os.makedirs(screenshots_dir, exist_ok=True)

test_results = []

def get_active_nav():
    return driver.execute_script('var el = document.querySelector(".bn-item.active"); return el ? el.getAttribute("data-nav") : "";')

def is_page_active(page_id):
    return driver.execute_script(f'var el = document.getElementById("{page_id}"); return el ? el.classList.contains("active") : false;')

def wait_for_page(page_id, timeout=8):
    start = time.time()
    while time.time() - start < timeout:
        if is_page_active(page_id):
            return True
        time.sleep(0.25)
    return is_page_active(page_id)

try:
    print("==================================================")
    print("STEP 5 ROUTER & BROWSER NAVIGATION TEST SUITE")
    print("==================================================")

    # 1. Test Direct Deep Link to Report for CF2979 & Month 2026-10
    print("\n--- Test 1: Direct Deep Link to Report for CF2979 & 2026-10 ---")
    driver.get(f"{base_data_url}#/report?id=CF2979&month=2026-10")
    driver.execute_script("try { localStorage.setItem('renata_preferred_id_v1', 'CF2979'); if(typeof closeModeSetupModal==='function')closeModeSetupModal(); } catch(e){}")
    report_active = wait_for_page('page-report', timeout=8)
    
    emp_id = driver.execute_script('var el = document.getElementById("reportEmpIdBadge"); return el ? el.textContent : "";')
    emp_name = driver.execute_script('var el = document.getElementById("reportEmpNameLbl"); return el ? el.textContent : "";')
    emp_sub = driver.execute_script('var el = document.getElementById("reportEmpSubLbl"); return el ? el.textContent : "";')
    lbl_total = driver.execute_script('var el = document.getElementById("lblGrandTotal"); return el ? el.textContent : "";')
    ot_hours = driver.execute_script('var el = document.getElementById("inpOtHours"); return el ? el.value : "";')
    active_nav = get_active_nav()
    
    print(f"Report Active: {report_active}")
    print(f"Bottom Nav Active: {active_nav} (Expected: report)")
    print(f"Employee Badge: {emp_id} (Expected: CF2979)")
    print(f"Employee Name: {emp_name} (Expected: Md. Rasel Mahmud)")
    print(f"Employee Sub: {emp_sub}")
    print(f"Grand Total Element: {lbl_total} (Expected: ৳ 8716.00)")
    print(f"OT Hours Input: {ot_hours} (Expected: 102)")
    
    assert report_active, "Expected page-report to be active"
    assert active_nav == "report", f"Expected active nav 'report', got {active_nav}"
    assert emp_id == "CF2979", f"Expected CF2979, got {emp_id}"
    assert "8716" in emp_sub or "8716" in lbl_total, f"Expected 8716 on-screen total"
    assert ot_hours == "102", f"Expected 102 ot hours, got {ot_hours}"
    
    ss_path = os.path.join(screenshots_dir, "step5_route_report_cf2979.png")
    driver.save_screenshot(ss_path)
    print(f"Saved screenshot: {ss_path}")
    test_results.append(("Deep Link #/report?id=CF2979&month=2026-10 (OT 102h, total 8716)", "PASS"))

    # 2. Test Refresh on Deep Link
    print("\n--- Test 2: Refresh on Deep Link ---")
    driver.refresh()
    report_active = wait_for_page('page-report', timeout=8)
    active_nav = get_active_nav()
    lbl_total = driver.execute_script('var el = document.getElementById("lblGrandTotal"); return el ? el.textContent : "";')
    print(f"After refresh: Page Report Active={report_active}, Nav Active={active_nav}, Total={lbl_total}")
    assert report_active and active_nav == "report", "Refresh did not preserve report page"
    assert "8716" in lbl_total or "8716" in driver.execute_script('var el = document.getElementById("reportEmpSubLbl"); return el ? el.textContent : "";')
    test_results.append(("Refresh on #/report deep link", "PASS"))

    # 3. Test Direct Navigation to all other routes
    routes_to_test = [
        ("search", "search", "page-search"),
        ("vs", "vs", "page-vs"),
        ("leaderboard", "leaderboard", "page-leaderboard"),
        ("notices", "more", "page-notices"),
        ("more", "more", "page-more"),
        ("team", "more", "page-team"),
        ("history", "more", "page-history"),
        ("settings", "more", "page-settings"),
    ]

    for route_name, expected_nav, page_elem_id in routes_to_test:
        print(f"\n--- Testing Route: #/{route_name} ---")
        driver.get(f"{base_data_url}#/{route_name}")
        page_active = wait_for_page(page_elem_id, timeout=5)
        active_nav = get_active_nav()
        print(f"Route #/{route_name} -> Page {page_elem_id} Active={page_active}, Nav Active={active_nav} (Expected: {expected_nav})")
        assert page_active, f"Expected {page_elem_id} to have class 'active'"
        assert active_nav == expected_nav, f"Expected bottom nav '{expected_nav}', got '{active_nav}'"
        
        # Test refresh on this route
        driver.refresh()
        page_active_ref = wait_for_page(page_elem_id, timeout=5)
        active_nav_ref = get_active_nav()
        assert page_active_ref, f"Refresh on #/{route_name} failed to preserve active page {page_elem_id}"
        assert active_nav_ref == expected_nav, f"Refresh on #/{route_name} failed to preserve active nav {expected_nav}"
        
        # Capture screenshot for key routes
        if route_name in ['search', 'leaderboard', 'vs', 'notices', 'settings']:
            ss_route_path = os.path.join(screenshots_dir, f"step5_route_{route_name}.png")
            driver.save_screenshot(ss_route_path)
            print(f"Saved screenshot: {ss_route_path}")
            
        test_results.append((f"Direct route & refresh: #/{route_name}", "PASS"))

    # 4. Test Browser Back / Forward History Navigation
    print("\n--- Test 4: Browser Back / Forward History Navigation ---")
    driver.get(f"{base_data_url}#/search")
    wait_for_page('page-search', timeout=5)
    
    # Switch via UI to leaderboard
    driver.execute_script("switchPage('leaderboard');")
    wait_for_page('page-leaderboard', timeout=5)
    url_lb = driver.execute_script("return window.location.hash;")
    nav_lb = get_active_nav()
    print(f"After switchPage('leaderboard'): Hash={url_lb}, nav={nav_lb}")
    assert "#/leaderboard" in url_lb, f"Hash did not update to #/leaderboard, got {url_lb}"
    assert nav_lb == "leaderboard"
    
    # Switch via UI to vs
    driver.execute_script("switchPage('vs');")
    wait_for_page('page-vs', timeout=5)
    url_vs = driver.execute_script("return window.location.hash;")
    nav_vs = get_active_nav()
    print(f"After switchPage('vs'): Hash={url_vs}, nav={nav_vs}")
    assert "#/vs" in url_vs
    assert nav_vs == "vs"
    
    # Browser Back -> should return to leaderboard
    driver.back()
    page_lb_active = wait_for_page('page-leaderboard', timeout=5)
    url_back1 = driver.execute_script("return window.location.hash;")
    nav_back1 = get_active_nav()
    print(f"After Browser Back 1: Hash={url_back1}, Leaderboard Active={page_lb_active}, nav={nav_back1}")
    assert "#/leaderboard" in url_back1, f"Expected #/leaderboard on back, got {url_back1}"
    assert page_lb_active, "Leaderboard page was not activated on back"
    assert nav_back1 == "leaderboard"
    
    # Browser Back -> should return to search
    driver.back()
    page_search_active = wait_for_page('page-search', timeout=5)
    url_back2 = driver.execute_script("return window.location.hash;")
    nav_back2 = get_active_nav()
    print(f"After Browser Back 2: Hash={url_back2}, Search Active={page_search_active}, nav={nav_back2}")
    assert "#/search" in url_back2, f"Expected #/search on back, got {url_back2}"
    assert page_search_active, "Search page was not activated on back"
    assert nav_back2 == "search"
    
    # Browser Forward -> should go back to leaderboard
    driver.forward()
    page_lb_active = wait_for_page('page-leaderboard', timeout=5)
    url_fwd = driver.execute_script("return window.location.hash;")
    print(f"After Browser Forward: Hash={url_fwd}, Leaderboard Active={page_lb_active}")
    assert "#/leaderboard" in url_fwd
    assert page_lb_active
    
    # Go back to search
    driver.back()
    wait_for_page('page-search', timeout=5)
    test_results.append(("Browser Back / Forward navigation", "PASS"))

    # 5. Test 'Press back again to exit' guard on Home (#/search)
    print("\n--- Test 5: Double-Back to Exit Guard on #/search ---")
    driver.get(f"{base_data_url}#/search")
    wait_for_page('page-search', timeout=5)
    
    # Trigger popstate as if user pressed back to sentinel
    toast_diag = driver.execute_script("""
        window.dispatchEvent(new PopStateEvent('popstate', { state: { renataApp: true, isSentinel: true } }));
        var tc = document.getElementById('toastContainer');
        return tc ? tc.innerHTML : '';
    """)
    print(f"Back on #/search Toast HTML: '{toast_diag}'")
    assert "exit" in toast_diag.lower(), f"Expected exit toast in HTML, got '{toast_diag}'"
    test_results.append(("Home double-back exit toast", "PASS"))

    # Check JavaScript runtime errors across all tests
    logs = driver.get_log('browser')
    js_errs = [l for l in logs if l['level'] == 'SEVERE' and 'ERR_NAME_NOT_RESOLVED' not in l['message']]
    print(f"\nTotal JavaScript Runtime Errors: {len(js_errs)}")
    if len(js_errs) > 0:
        for err in js_errs:
            print("  SEVERE JS ERROR:", err["message"][:250])
    if len(js_errs) > 0:
        for e in js_errs: print("ERROR:", e["message"][-300:])
    assert len(js_errs) == 0, f"Expected 0 JavaScript runtime errors, got {len(js_errs)}"
    test_results.append(("Zero JavaScript runtime errors (0 errors)", "PASS"))

    print("\n==================================================")
    print("ALL TESTS PASSED SUCCESSFULLY!")
    print("==================================================")
    for name, res in test_results:
        print(f"[{res}] {name}")

except Exception as e:
    print(f"\nTEST FAILED WITH EXCEPTION: {e}", file=sys.stderr)
    import traceback
    traceback.print_exc()
    sys.exit(1)
finally:
    driver.quit()
