

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const repoDir = __dirname.endsWith('tests') ? path.resolve(__dirname, '..') : __dirname;
const baselinePath = path.join(repoDir, 'tests', 'benchmark_baseline.json');
const baseline = JSON.parse(fs.readFileSync(baselinePath, 'utf8'));

const html = fs.readFileSync(path.join(repoDir, 'index.html'), 'utf8');
const sStart = html.lastIndexOf('<script>');
const sEnd = html.lastIndexOf('</script>');
const scriptContent = html.slice(sStart + 8, sEnd);

const storage = {};
global.localStorage = {
  getItem: (k) => storage[k] ?? null,
  setItem: (k, v) => { storage[k] = String(v); },
  removeItem: (k) => { delete storage[k]; },
  clear: () => { Object.keys(storage).forEach(k => delete storage[k]); }
};
global.window = global;
global.window.addEventListener = () => {};
global.window.removeEventListener = () => {};
global.window.scrollTo = () => {};
global.requestAnimationFrame = (cb) => setTimeout(cb, 0);
global.cancelAnimationFrame = (id) => clearTimeout(id);
global.matchMedia = () => ({ matches: false, addListener: ()=>{}, removeListener: ()=>{} });
global.location = { protocol: 'https:', href: 'https://checkot.github.io/', hostname: 'checkot.github.io', hash: '' };
global.history = { replaceState: ()=>{}, pushState: ()=>{}, back: ()=>{} };
global.navigator = { userAgent: 'node', canShare: false };

global.fetch = async (url) => {
  const cleanUrl = url.split('?')[0].replace('https://checkot.github.io/', '');
  const filePath = path.join(repoDir, cleanUrl);
  if (fs.existsSync(filePath)) {
    const content = fs.readFileSync(filePath, 'utf8');
    return { ok: true, status: 200, json: async () => JSON.parse(content), text: async () => content };
  }
  return { ok: false, status: 404 };
};

const makeEl = (id = '') => ({
  id, value: '', textContent: '', innerText: '', innerHTML: '', options: [], style: {}, focus: ()=>{}, blur: ()=>{},
  classList: { add: ()=>{}, remove: ()=>{}, contains: ()=>false, toggle: ()=>{} },
  setAttribute: ()=>{}, removeAttribute: ()=>{}, addEventListener: ()=>{}, appendChild: ()=>{}, querySelector: ()=>null, querySelectorAll: ()=>[]
});

global.document = {
  getElementById: (id) => makeEl(id), querySelector: () => makeEl(), querySelectorAll: () => [],
  addEventListener: () => {}, removeEventListener: () => {}, createElement: (tag) => makeEl(tag),
  documentElement: { setAttribute: ()=>{}, getAttribute: ()=>null },
  body: { style: {}, classList: { add: ()=>{}, remove: ()=>{}, contains: ()=>false, toggle: ()=>{} }, dataset: {} }
};


// Load modular JS files first, identical to browser execution order
const jsFiles = [
  'js/core/config.js',
  'js/core/state.js',
  'js/core/storage.js',
  'js/core/utils.js',
  'js/calculations/rates.js',
  'js/calculations/ranking.js',
  'js/components/router.js',
  'js/pages/search.js',
  'js/pages/history.js',
  'js/pages/settings.js',
  'js/pages/report.js',
  'js/pages/vs.js',
  'js/pages/leaderboard.js',
  'js/pages/notices.js',
  'js/pages/more.js',
  'js/pages/team.js'
];
for (const jf of jsFiles) {
  const p = path.join(repoDir, jf);
  if (fs.existsSync(p)) {
    vm.runInThisContext(fs.readFileSync(p, 'utf8'));
  }
}

vm.runInThisContext(scriptContent);

setTimeout(() => {
  console.log('--- Running Multi-Month Regression Test Suite ---');
  let passed = 0;
  let failed = 0;

  for (const [monthStr, empList] of Object.entries(baseline.months)) {
    console.log(`\nChecking Month: ${monthStr} (${empList.length} benchmark employees)...`);
    const monthDataPath = path.join(repoDir, 'data', `${monthStr}.json`);
    const monthData = JSON.parse(fs.readFileSync(monthDataPath, 'utf8'));
    const empMap = {};
    monthData.employees.forEach(e => { empMap[e.id] = e; });

    empList.forEach(expected => {
      const actualEmp = empMap[expected.id];
      if (!actualEmp) {
        console.error(`FAIL: Employee ${expected.id} missing from ${monthStr}`);
        failed++;
        return;
      }

      applyTypeOverride(actualEmp);
      const rc = getRateCategory(actualEmp);
      const cat = actualEmp.category || rc.cat || 'JO';
      const r = RATE_TABLE[cat] || RATE_TABLE.JO;

      const otHours = Number(actualEmp.otHours) || 0;
      const holidayCount = Number(actualEmp.holidayCount != null ? actualEmp.holidayCount : actualEmp.holiday) || 0;
      const nightCount = Number(actualEmp.nightCount != null ? actualEmp.nightCount : actualEmp.night) || 0;

      const otAmount = actualEmp.otAmount != null ? Number(actualEmp.otAmount) : (otHours * r.otRate);
      const holidayAmount = actualEmp.holidayAmount != null
        ? Number(actualEmp.holidayAmount)
        : (r.holidayType === "hourly" ? holidayCount * r.holidayHours * r.otRate : holidayCount * r.holidayFlat);
      const nightAmount = actualEmp.nightAmount != null ? Number(actualEmp.nightAmount) : (nightCount * r.nightRate);
      const totalEarned = actualEmp.totalEarned != null ? Number(actualEmp.totalEarned) : (otAmount + holidayAmount + nightAmount);

      const matches = (
        otAmount === expected.otAmount &&
        holidayAmount === expected.holidayAmount &&
        nightAmount === expected.nightAmount &&
        totalEarned === expected.totalEarned
      );

      if (matches) {
        console.log(`PASS: [${monthStr}] ${expected.id} (${expected.name}) [${expected.category} ৳${r.otRate}/h] - OT: ৳${otAmount}, Hol: ৳${holidayAmount}, Ngt: ৳${nightAmount}, Total: ৳${totalEarned}`);
        passed++;
      } else {
        console.error(`FAIL: [${monthStr}] ${expected.id} (${expected.name}) mismatch! Expected total ${expected.totalEarned}, got ${totalEarned}`);
        failed++;
      }
    });
  }

  // 4. Leaderboard Ranking Order & Score Parity (Oct 2026)
  const octEmps = JSON.parse(fs.readFileSync(path.join(repoDir, 'data', '2026-10.json'), 'utf8')).employees;
  const lbPayload = buildLeaderboardPayloadFromList('2026-10', octEmps);
  const top3 = lbPayload.sortedByEarned.slice(0, 3).map(x => ({ id: x.id, earned: x.totalEarned }));
  const expTop3 = [
    { id: 'CF2979', earned: 8716 },
    { id: 'RF8365', earned: 8360 },
    { id: 'RF22095', earned: 8320 }
  ];

  let lbMatches = (top3.length === expTop3.length);
  for (let i = 0; i < top3.length; i++) {
    if (top3[i].id !== expTop3[i].id || top3[i].earned !== expTop3[i].earned) {
      lbMatches = false;
      break;
    }
  }

  if (lbMatches) {
    console.log(`PASS: Leaderboard Top 3: #1 ${top3[0].id} (৳${top3[0].earned}), #2 ${top3[1].id} (৳${top3[1].earned}), #3 ${top3[2].id} (৳${top3[2].earned})`);
    passed++;
  } else {
    console.error(`FAIL: Leaderboard ranking mismatch!`, top3, expTop3);
    failed++;
  }

  // 5. Test Historical Rate Preservation Rule
  console.log('\n--- Testing Historical Rate Preservation (Simulating Active Rate Change) ---');
  const octEmpsForRateTest = JSON.parse(fs.readFileSync(path.join(repoDir, 'data', '2026-10.json'), 'utf8')).employees;
  const cfEmp = octEmpsForRateTest.find(e => e.id === 'CF2979');
  const joEmp = octEmpsForRateTest.find(e => e.id === 'RF8365');

  const origCfRate = RATE_TABLE.CF.otRate;
  const origJoRate = RATE_TABLE.JO.otRate;
  RATE_TABLE.CF.otRate = 999;
  RATE_TABLE.JO.otRate = 888;

  const cfTotal = cfEmp.totalEarned != null ? Number(cfEmp.totalEarned) : (Number(cfEmp.otHours) * RATE_TABLE.CF.otRate);
  const joTotal = joEmp.totalEarned != null ? Number(joEmp.totalEarned) : (Number(joEmp.otHours) * RATE_TABLE.JO.otRate);

  RATE_TABLE.CF.otRate = origCfRate;
  RATE_TABLE.JO.otRate = origJoRate;

  if (cfTotal === 8716 && joTotal === 8360) {
    console.log('PASS: Historical Rate Isolation Proven:');
    console.log(`  CF2979 kept 2026-10 rate (৳38/hr) = ৳${cfTotal} (ignored active ৳999/hr)`);
    console.log(`  RF8365 kept 2026-10 rate (৳40/hr) = ৳${joTotal} (ignored active ৳888/hr)`);
    passed++;
  } else {
    console.error(`FAIL: Past month rates were overridden by active table! CF: ${cfTotal}, JO: ${joTotal}`);
    failed++;
  }

  console.log(`\n================================`);
  console.log(`RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log(`================================`);
  process.exit(failed > 0 ? 1 : 0);
}, 100);
