#!/usr/bin/env python3
"""
tests/test_parity.py
====================
Comprehensive Functional Parity Test Suite
Directly compares the ORIGINAL Step 0 monolithic index.html against
the CURRENT modular index.html across all functional features:

1. Leaderboard:
   - Areas: Solid Production, Softgel Production, Packing Hall, Overall (in In-Charge mode)
   - Sub-sections: Granulation, Compression, Coating, Encapsulation, Blister Packing, etc.
   - Gender filters: All, Male (M), Female (F)
   - Category filters: All, CF, JO
   - Time modes: 2026-10, Previous month (2026-09), Last 3 months (3m), Last 6 months (6m), All-time (all)
   - Metrics compared: Top 10 IDs, Top 10 Totals, and Total rendered row count
2. Report View (CF2979 and RF8365):
   - All on-screen values: Grand Total, OT Hours, OT Amount, Days summary (Regular, Holiday, Night, Plain)
   - Canvas 2D PNG Payslip export: non-empty PNG, dimension parity (width, height)
3. VS Comparison:
   - 2-employee comparison (CF2979 vs RF8365)
   - 3-employee comparison (CF2979 vs RF8365 vs RF22095)
   - Table cells, winner highlights, difference summaries
4. History Management:
   - Add to history, rendered recent items, clearHistory() empty state
5. Settings:
   - Preferred ID save and persistence
   - Theme toggle (light/dark)
   - Language toggle (bn/en)
6. Notices Page:
   - Notice cards count, titles, dates, priorities
7. Team Page:
   - Team member cards count, names, designations, areas
"""

import json
import os
import re
import sys
import time
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

REPO_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ORIG_HTML_PATH = os.path.join(REPO_DIR, 'tests', 'fixtures', 'original_index.html')
CUR_HTML_PATH = os.path.join(REPO_DIR, 'index.html')

if not os.path.exists(ORIG_HTML_PATH):
    alt_path = '/working_dir/c_36c11a2e461632fa/repo_original/checkot.github.io-main/index.html'
    if os.path.exists(alt_path):
        import shutil
        os.makedirs(os.path.dirname(ORIG_HTML_PATH), exist_ok=True)
        shutil.copyfile(alt_path, ORIG_HTML_PATH)
    else:
        raise FileNotFoundError(f"Original index.html fixture not found at {ORIG_HTML_PATH}")

# Load JSON data fixtures
with open(os.path.join(REPO_DIR, 'areas.json'), encoding='utf-8') as f: areas_data = json.load(f)
with open(os.path.join(REPO_DIR, 'notices.json'), encoding='utf-8') as f: notices_data = json.load(f)
with open(os.path.join(REPO_DIR, 'team.json'), encoding='utf-8') as f: team_data = json.load(f)
with open(os.path.join(REPO_DIR, 'absent.json'), encoding='utf-8') as f: absent_data = json.load(f)

# Load monthly data files for time-range tests
months_to_load = ['2026-10', '2026-09', '2026-08', '2026-07', '2026-06', '2026-05', '2026-03', '2026-01']
mock_data = {
    'areas.json': areas_data,
    'notices.json': notices_data,
    'team.json': team_data,
    'absent.json': absent_data
}

for ym in months_to_load:
    fp = os.path.join(REPO_DIR, 'data', f'{ym}.json')
    if os.path.exists(fp):
        with open(fp, encoding='utf-8') as f:
            mock_data[f'data/{ym}.json'] = json.load(f)

if 'data/2026-10.json' in mock_data:
    mock_data['data/latest.json'] = mock_data['data/2026-10.json']

# Base storage and fetch shim
POLY_SCRIPT = f'''<script>
(function() {{
  const _s = {{}};
  const mockStorage = {{
    getItem: k => (_s[k] !== undefined ? _s[k] : null),
    setItem: (k, v) => {{ _s[k] = String(v); }},
    removeItem: k => {{ delete _s[k]; }},
    clear: () => {{ Object.keys(_s).forEach(k => delete _s[k]); }},
    key: i => Object.keys(_s)[i] || null,
    get length() {{ return Object.keys(_s).length; }}
  }};
  try {{
    Object.defineProperty(window, 'localStorage', {{ value: mockStorage, configurable: true, writable: true }});
    Object.defineProperty(window, 'sessionStorage', {{ value: mockStorage, configurable: true, writable: true }});
  }} catch(e) {{}}
  window.__injectedMockData = {json.dumps(mock_data)};
  window.fetch = async (url) => {{
    const clean = String(url).split('?')[0].replace('https://checkot.github.io/', '').replace(/^https?:\\/\\/[^\\/]+\\//, '');
    if (window.__injectedMockData[clean]) {{
      const d = window.__injectedMockData[clean];
      return {{ ok: true, status: 200, json: async () => d, text: async () => JSON.stringify(d) }};
    }}
    return {{ ok: false, status: 404 }};
  }};
}})();
</script>'''

def build_html_bundle(raw_html, is_current=False):
    if is_current:
        def repl_css(m):
            try:
                with open(os.path.join(REPO_DIR, m.group(1)), encoding='utf-8') as cf:
                    return f'<style>/* {m.group(1)} */\n{cf.read()}\n</style>'
            except:
                return m.group(0)
        raw_html = re.sub(r'<link rel="stylesheet" href="([^"]+)">', repl_css, raw_html)

        def repl_js(m):
            try:
                with open(os.path.join(REPO_DIR, m.group(1)), encoding='utf-8') as jf:
                    return f'<script>/* {m.group(1)} */\n{jf.read()}\n</script>'
            except:
                return m.group(0)
        raw_html = re.sub(r'<script src="([^"]+)"></script>', repl_js, raw_html)

    raw_html = raw_html.replace('<head>', '<head>\n' + POLY_SCRIPT)
    raw_html = raw_html.replace(
        '<img class="logo" src="https://checkot.github.io/icon.png"',
        '<img class="logo" src="data:image/svg+xml;utf8,<svg></svg>"'
    )
    raw_html = re.sub(r'<link[^>]+fonts\.googleapis\.com[^>]+>', '', raw_html)
    return raw_html

def spawn_driver(html_content):
    opts = Options()
    opts.add_argument('--headless=new')
    opts.add_argument('--no-sandbox')
    opts.add_argument('--disable-dev-shm-usage')
    opts.add_argument('--disable-gpu')
    opts.add_argument('--window-size=1280,1024')
    opts.set_capability('goog:loggingPrefs', {'browser': 'ALL'})

    driver = webdriver.Chrome(options=opts)
    driver.get('data:text/html,<html><head></head><body></body></html>')
    frame_id = driver.execute_cdp_cmd('Page.getFrameTree', {})['frameTree']['frame']['id']
    driver.execute_cdp_cmd('Page.setDocumentContent', {
        'frameId': frame_id,
        'html': html_content
    })
    time.sleep(1.5)
    return driver

print("==================================================")
print("STARTING COMPREHENSIVE FUNCTIONAL PARITY TEST SUITE")
print("==================================================")

with open(ORIG_HTML_PATH, encoding='utf-8') as f: orig_raw = f.read()
with open(CUR_HTML_PATH, encoding='utf-8') as f: cur_raw = f.read()

orig_bundle = build_html_bundle(orig_raw, is_current=False)
cur_bundle = build_html_bundle(cur_raw, is_current=True)

driver_orig = spawn_driver(orig_bundle)
driver_cur = spawn_driver(cur_bundle)

test_failures = []
test_passes = []

def record_assertion(test_name, val_orig, val_cur):
    if val_orig == val_cur:
        test_passes.append(test_name)
        print(f"  [PASS] {test_name}")
    else:
        test_failures.append((test_name, val_orig, val_cur))
        print(f"  [FAIL] {test_name} -> Orig: {val_orig} | Cur: {val_cur}", file=sys.stderr)

try:
    # ----------------------------------------------------
    # TEST SUITE 1: LEADERBOARD MULTI-FACTOR PARITY
    # ----------------------------------------------------
    print("\n--- Test Suite 1: Leaderboard Multi-Factor Parity ---")
    
    # 1.1 Base Leaderboard (2026-10, All areas, All sub, All gender, All type)
    for d in [driver_orig, driver_cur]:
        d.execute_script("switchPage('leaderboard'); startLeaderboardScan(false);")
    time.sleep(2)

    def get_lb_state(d):
        return d.execute_script('''
            const res = currentLeaderboardResult;
            if (!res) return { count: 0, top10: [] };
            const list = res.filtered ? res.filtered.sortedByEarned : res.sortedByEarned;
            return {
                count: list.length,
                top10: list.slice(0, 10).map(e => ({ id: e.id, total: e.totalEarned, ot: e.otHours, duty: e.totalDuty }))
            };
        ''')

    st_orig = get_lb_state(driver_orig)
    st_cur = get_lb_state(driver_cur)
    record_assertion("Leaderboard 2026-10 Base Count", st_orig['count'], st_cur['count'])
    record_assertion("Leaderboard 2026-10 Base Top 10 IDs & Totals", st_orig['top10'], st_cur['top10'])

    # 1.2 Area Filter Parity: Solid, Softgel, Packing
    areas = ['Solid Production', 'Softgel Production', 'Packing Hall']
    for a in areas:
        for d in [driver_orig, driver_cur]:
            d.execute_script(f"""
                document.getElementById('areaFilter').value = '{a}';
                document.getElementById('subFilter').value = 'all';
                applyAreaFilter();
            """)
        time.sleep(0.5)
        st_o = get_lb_state(driver_orig)
        st_c = get_lb_state(driver_cur)
        record_assertion(f"Leaderboard Area: {a} (Count: {st_o['count']})", st_o, st_c)

    # 1.3 Sub-section Filter Parity
    sub_tests = [
        ('Solid Production', 'Granulation'),
        ('Solid Production', 'Compression'),
        ('Solid Production', 'Coating'),
        ('Softgel Production', 'Encapsulation'),
        ('Softgel Production', 'Gelatin Prep'),
        ('Packing Hall', 'Blister Packing'),
        ('Packing Hall', 'Strip & Alu-Alu')
    ]
    for area, sub in sub_tests:
        for d in [driver_orig, driver_cur]:
            d.execute_script(f"""
                document.getElementById('areaFilter').value = '{area}';
                refreshSubFilter();
                document.getElementById('subFilter').value = '{sub}';
                applyAreaFilter();
            """)
        time.sleep(0.5)
        st_o = get_lb_state(driver_orig)
        st_c = get_lb_state(driver_cur)
        record_assertion(f"Leaderboard Sub: {area} > {sub}", st_o, st_c)

    # 1.4 Gender & Category Filters
    for g in ['M', 'F']:
        for d in [driver_orig, driver_cur]:
            d.execute_script(f"""
                document.getElementById('areaFilter').value = 'all';
                document.getElementById('subFilter').value = 'all';
                document.getElementById('genderFilter').value = '{g}';
                applyAreaFilter();
            """)
        time.sleep(0.5)
        st_o = get_lb_state(driver_orig)
        st_c = get_lb_state(driver_cur)
        record_assertion(f"Leaderboard Gender: {g}", st_o, st_c)

    for cat in ['CF', 'JO']:
        for d in [driver_orig, driver_cur]:
            d.execute_script(f"""
                document.getElementById('areaFilter').value = 'all';
                document.getElementById('subFilter').value = 'all';
                document.getElementById('genderFilter').value = 'all';
                document.getElementById('typeFilter').value = '{cat}';
                applyAreaFilter();
            """)
        time.sleep(0.5)
        st_o = get_lb_state(driver_orig)
        st_c = get_lb_state(driver_cur)
        record_assertion(f"Leaderboard Category: {cat}", st_o, st_c)

    # Reset filters
    for d in [driver_orig, driver_cur]:
        d.execute_script("""
            document.getElementById('areaFilter').value = 'all';
            document.getElementById('subFilter').value = 'all';
            document.getElementById('genderFilter').value = 'all';
            document.getElementById('typeFilter').value = 'all';
            applyAreaFilter();
        """)

    # 1.5 Overall Area in In-Charge Mode
    for d in [driver_orig, driver_cur]:
        d.execute_script("""
            setAppMode('incharge');
            syncPrivilegedUI();
            populateAreaDropdown();
            document.getElementById('areaFilter').value = 'Overall';
            applyAreaFilter();
        """)
    time.sleep(0.5)
    st_o = get_lb_state(driver_orig)
    st_c = get_lb_state(driver_cur)
    record_assertion(f"Leaderboard In-Charge Overall Area (Count: {st_o['count']})", st_o, st_c)

    # Reset app mode back to employee
    for d in [driver_orig, driver_cur]:
        d.execute_script("setAppMode('employee'); syncPrivilegedUI(); populateAreaDropdown(); document.getElementById('areaFilter').value = 'all'; applyAreaFilter();")

    # 1.6 Time Modes: Previous Month, 3m, 6m, All-time
    # Previous Month (2026-09)
    for d in [driver_orig, driver_cur]:
        d.execute_script("""
            document.getElementById('lbMonthSelect').value = '09';
            onLbMonthYearChange();
        """)
    time.sleep(1.5)
    st_o = get_lb_state(driver_orig)
    st_c = get_lb_state(driver_cur)
    record_assertion("Leaderboard Previous Month (2026-09)", st_o, st_c)

    # Multi-month modes (3m, 6m, all)
    for mode in ['3m', '6m', 'all']:
        for d in [driver_orig, driver_cur]:
            d.execute_script(f"switchLbTimeMode('{mode}');")
        time.sleep(1.5)
        st_o = get_lb_state(driver_orig)
        st_c = get_lb_state(driver_cur)
        record_assertion(f"Leaderboard Time Mode: {mode} (Count: {st_o['count']})", st_o, st_c)

    # ----------------------------------------------------
    # TEST SUITE 2: REPORT DETAILS & PAYSLIP CANVAS PNG
    # ----------------------------------------------------
    print("\n--- Test Suite 2: Report View & Payslip PNG Export Parity ---")
    
    test_employees = ['CF2979', 'RF8365']
    for emp_id in test_employees:
        for d in [driver_orig, driver_cur]:
            d.execute_script(f"""
                switchPage('search');
                document.getElementById('employeeId').value = '{emp_id}';
                document.getElementById('yearSelect').value = '2026';
                document.getElementById('monthSelect').value = '10';
                findReport();
            """)
        time.sleep(1.5)

        def get_report_metrics(d):
            return d.execute_script('''
                return {
                    grandTotal: document.getElementById('lblGrandTotal').innerText.trim(),
                    otHours: document.getElementById('inpOtHours').value.trim(),
                    otAmount: document.getElementById('lblOtAmount').innerText.trim(),
                    otFormula: document.getElementById('lblOtFormula').innerText.trim(),
                    categoryBadge: document.getElementById('categoryBadge').innerText.trim(),
                    regDays: document.getElementById('dsRegularDays').innerText.trim(),
                    holDays: document.getElementById('dsHolidayDays').innerText.trim(),
                    ngtDays: document.getElementById('dsNightDays').innerText.trim(),
                    plnDays: document.getElementById('dsPlainDays').innerText.trim()
                };
            ''')

        rep_o = get_report_metrics(driver_orig)
        rep_c = get_report_metrics(driver_cur)
        record_assertion(f"Report Summary Numbers for {emp_id}", rep_o, rep_c)

        # Payslip PNG Export Canvas comparison
        def get_canvas_png_specs(d):
            return d.execute_async_script('''
                const done = arguments[arguments.length - 1];
                generateWorkLogCanvas2D(window._rptCtx).then(canvas => {
                    done({
                        width: canvas.width,
                        height: canvas.height,
                        hasContent: canvas.width > 0 && canvas.height > 0
                    });
                }).catch(err => {
                    done({ error: String(err) });
                });
            ''')

        png_o = get_canvas_png_specs(driver_orig)
        png_c = get_canvas_png_specs(driver_cur)
        record_assertion(f"Payslip PNG Canvas Dimensions for {emp_id}", (png_o['width'], png_o['height']), (png_c['width'], png_c['height']))
        record_assertion(f"Payslip PNG Non-Empty Valid Content for {emp_id}", png_o['hasContent'], png_c['hasContent'])

    # ----------------------------------------------------
    # TEST SUITE 3: VS COMPARISON PARITY
    # ----------------------------------------------------
    print("\n--- Test Suite 3: VS Comparison Parity ---")
    
    # 3.1 2 IDs Comparison (CF2979 vs RF8365)
    for d in [driver_orig, driver_cur]:
        d.execute_script("""
            switchPage('vs');
            setVsMode(2);
            document.getElementById('compareId1').value = 'CF2979';
            document.getElementById('compareId').value = 'RF8365';
            runComparison();
        """)
    time.sleep(1.5)

    def get_vs_summary(d):
        return d.execute_script('''
            const table = document.querySelector('#vsExportTarget table.compare-table');
            const diffEl = document.querySelector('#vsExportTarget .compare-diff');
            return {
                hasTable: Boolean(table),
                rowCount: table ? table.querySelectorAll('tr').length : 0,
                diffText: diffEl ? diffEl.innerText.trim() : '',
                totalRow: table && table.querySelector('tr.total-row') ? table.querySelector('tr.total-row').innerText.replace(/\\s+/g, ' ').trim() : ''
            };
        ''')

    vs2_o = get_vs_summary(driver_orig)
    vs2_c = get_vs_summary(driver_cur)
    record_assertion("VS 2-Employee Comparison (CF2979 vs RF8365)", vs2_o, vs2_c)

    # 3.2 3 IDs Comparison (CF2979 vs RF8365 vs RF22095)
    for d in [driver_orig, driver_cur]:
        d.execute_script("""
            setVsMode(3);
            document.getElementById('compareId1').value = 'CF2979';
            document.getElementById('compareId').value = 'RF8365';
            document.getElementById('compareId3').value = 'RF22095';
            runComparison();
        """)
    time.sleep(1.5)

    vs3_o = get_vs_summary(driver_orig)
    vs3_c = get_vs_summary(driver_cur)
    record_assertion("VS 3-Employee Comparison (CF2979 vs RF8365 vs RF22095)", vs3_o, vs3_c)

    # ----------------------------------------------------
    # TEST SUITE 4: HISTORY MANAGEMENT PARITY
    # ----------------------------------------------------
    print("\n--- Test Suite 4: History Management Parity ---")
    
    for d in [driver_orig, driver_cur]:
        d.execute_script("""
            switchPage('history');
            addToHistory('CF2979', '2026-10', 'Md. Rasel Mahmud');
            addToHistory('RF8365', '2026-10', 'Rubel Mia');
            renderHistory();
        """)
    time.sleep(0.5)

    def get_history_items(d):
        return d.execute_script('''
            const items = document.querySelectorAll('#historyList .history-item');
            return Array.from(items).map(i => i.innerText.replace(/\\s+/g, ' ').trim());
        ''')

    hist_o = get_history_items(driver_orig)
    hist_c = get_history_items(driver_cur)
    record_assertion("History Rendered Items", hist_o, hist_c)

    # Clear history
    for d in [driver_orig, driver_cur]:
        d.execute_script("clearHistory(); renderHistory();")
    time.sleep(0.5)
    chist_o = get_history_items(driver_orig)
    chist_c = get_history_items(driver_cur)
    record_assertion("History Clear Parity", chist_o, chist_c)

    # ----------------------------------------------------
    # TEST SUITE 5: SETTINGS & PERSISTENCE PARITY
    # ----------------------------------------------------
    print("\n--- Test Suite 5: Settings & Preferences Parity ---")
    
    # 5.1 Save Preferred ID
    for d in [driver_orig, driver_cur]:
        d.execute_script("setPreferredId('CF2979');")
    time.sleep(0.3)
    pref_o = driver_orig.execute_script("return getPreferredId();")
    pref_c = driver_cur.execute_script("return getPreferredId();")
    record_assertion("Settings Preferred ID Persistence", pref_o, pref_c)

    # 5.2 Theme Toggle (dark & light)
    for theme in ['dark', 'light']:
        for d in [driver_orig, driver_cur]:
            d.execute_script(f"setTheme('{theme}');")
        time.sleep(0.3)
        th_o = driver_orig.execute_script("return document.documentElement.getAttribute('data-theme');")
        th_c = driver_cur.execute_script("return document.documentElement.getAttribute('data-theme');")
        record_assertion(f"Settings Theme Attribute ({theme})", th_o, th_c)

    # 5.3 Language Toggle (bn & en)
    for lang in ['bn', 'en']:
        for d in [driver_orig, driver_cur]:
            d.execute_script(f"setLanguage('{lang}');")
        time.sleep(0.3)
        l_o = driver_orig.execute_script("return document.documentElement.lang;")
        l_c = driver_cur.execute_script("return document.documentElement.lang;")
        record_assertion(f"Settings Language Attribute ({lang})", l_o, l_c)

    # ----------------------------------------------------
    # TEST SUITE 6: NOTICES PAGE PARITY
    # ----------------------------------------------------
    print("\n--- Test Suite 6: Notices Page Parity ---")
    
    for d in [driver_orig, driver_cur]:
        d.execute_script("switchPage('notices'); renderNoticesPage();")
    time.sleep(0.5)

    def get_notices_summary(d):
        return d.execute_script('''
            const cards = document.querySelectorAll('#noticesFullList .notice-card');
            return {
                cardCount: cards.length,
                titles: Array.from(cards).map(c => c.querySelector('.notice-title') ? c.querySelector('.notice-title').innerText.trim() : '')
            };
        ''')

    ntc_o = get_notices_summary(driver_orig)
    ntc_c = get_notices_summary(driver_cur)
    record_assertion("Notices Cards Count & Titles", ntc_o, ntc_c)

    # ----------------------------------------------------
    # TEST SUITE 7: TEAM PAGE PARITY
    # ----------------------------------------------------
    print("\n--- Test Suite 7: Team Page Parity ---")
    
    for d in [driver_orig, driver_cur]:
        d.execute_script("switchPage('team'); renderTeamPage();")
    time.sleep(0.5)

    def get_team_summary(d):
        return d.execute_script('''
            const cards = document.querySelectorAll('#teamGrid .team-card');
            return {
                memberCount: cards.length,
                names: Array.from(cards).map(c => c.querySelector('.team-name') ? c.querySelector('.team-name').innerText.trim() : '')
            };
        ''')

    tm_o = get_team_summary(driver_orig)
    tm_c = get_team_summary(driver_cur)
    record_assertion("Team Member Count & Names", tm_o, tm_c)

finally:
    driver_orig.quit()
    driver_cur.quit()

print("\n==================================================")
print(f"PARITY TEST RESULTS: {len(test_passes)} PASSED, {len(test_failures)} FAILED")
print("==================================================")

if len(test_failures) > 0:
    print(f"\nFAILED ASSERTIONS ({len(test_failures)}):", file=sys.stderr)
    for name, vo, vc in test_failures:
        print(f"  - {name}: Expected (Orig) {vo} != Got (Cur) {vc}", file=sys.stderr)
    sys.exit(1)
else:
    print("\nALL FUNCTIONAL PARITY TESTS PASSED 100% WITH ZERO DIFFERENCES!")
    sys.exit(0)
