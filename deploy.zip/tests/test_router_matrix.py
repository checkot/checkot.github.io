import json
import urllib.parse
import re
import time
import os
import sys
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

repo_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
index_path = os.path.join(repo_dir, 'index.html')

with open(index_path, 'r', encoding='utf-8') as f:
    html = f.read()

def repl_css(m):
    href = m.group(1)
    try:
        with open(os.path.join(repo_dir, href), 'r', encoding='utf-8') as cf:
            return f'<style>/* {href} */\n{cf.read()}\n</style>'
    except Exception as e:
        return m.group(0)

html = re.sub(r'<link rel="stylesheet" href="([^"]+)">', repl_css, html)

def repl_js(m):
    src = m.group(1)
    try:
        with open(os.path.join(repo_dir, src), 'r', encoding='utf-8') as jf:
            return f'<script>/* {src} */\n{jf.read()}\n</script>'
    except Exception as e:
        return m.group(0)

html = re.sub(r'<script src="([^"]+)"></script>', repl_js, html)

with open(os.path.join(repo_dir, 'areas.json')) as f: areas = json.load(f)
with open(os.path.join(repo_dir, 'notices.json')) as f: notices = json.load(f)
with open(os.path.join(repo_dir, 'team.json')) as f: team = json.load(f)
with open(os.path.join(repo_dir, 'absent.json')) as f: absent = json.load(f)
with open(os.path.join(repo_dir, 'data/2026-10.json')) as f: oct_full = json.load(f)
with open(os.path.join(repo_dir, 'tests/benchmark_baseline.json')) as f: baseline = json.load(f)

b_ids = set()
for m, emps in baseline['months'].items():
    for e in emps: b_ids.add(e['id'])

oct_sample = dict(oct_full)
oct_sample['employees'] = [e for e in oct_full['employees'] if e['id'] in b_ids or oct_full['employees'].index(e) < 30]

mock_data = {
    'areas.json': areas,
    'notices.json': notices,
    'team.json': team,
    'absent.json': absent,
    'data/2026-10.json': oct_sample,
    'data/latest.json': oct_sample
}

mock_script = f'''<script>
window.mockFetchData = {json.dumps(mock_data)};
window.fetch = async (url) => {{
  const clean = String(url).split('?')[0].replace('https://checkot.github.io/', '').replace(/^https?:\\/\\/[^\\/]+\\//, '');
  if (window.mockFetchData[clean]) {{
    const d = window.mockFetchData[clean];
    return {{ ok: true, status: 200, json: async () => d, text: async () => JSON.stringify(d) }};
  }}
  return {{ ok: false, status: 404 }};
}};
</script>'''

html = html.replace('</head>', mock_script + '\n</head>')
html = html.replace('<img class="logo" src="https://checkot.github.io/icon.png"', '<img class="logo" src="data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'32\' height=\'32\'></svg>"')
html = re.sub(r'<link[^>]+fonts\.googleapis\.com[^>]+>', '', html)

base_data_url = 'data:text/html;charset=utf-8,' + urllib.parse.quote(html)

screenshots_dir = os.path.join(repo_dir, 'screenshots')
os.makedirs(screenshots_dir, exist_ok=True)

test_matrix = [
    # (width, height, theme, lang, incharge)
    (360, 800, 'light', 'bn', False),
    (360, 800, 'dark', 'en', True),
    (412, 915, 'light', 'en', True),
    (412, 915, 'dark', 'bn', False),
]

routes = ['more', 'team', 'history', 'report', 'search', 'leaderboard']

options = Options()
options.add_argument('--headless=new')
options.add_argument('--no-sandbox')
options.add_argument('--disable-dev-shm-usage')
options.add_argument('--disable-gpu')
options.set_capability('goog:loggingPrefs', {'browser': 'ALL'})

driver = webdriver.Chrome(options=options)

try:
    print("==================================================")
    print("STEP 6 EXTENDED ROUTER MATRIX TEST SUITE")
    print("Resolutions: 360x800 & 412x915 | Themes: Light & Dark | Lang: BN & EN | Mode: InCharge ON/OFF")
    print("==================================================")

    matrix_passes = 0
    total_configs = len(test_matrix)

    for w, h, theme, lang, incharge in test_matrix:
        driver.set_window_size(w, h)
        config_desc = f"{w}x{h}_{theme}_{lang}_{'inc' if incharge else 'emp'}"
        print(f"\n--- Testing Configuration: {config_desc} ---")
        
        # Load base page
        driver.get(f"{base_data_url}#/search")
        time.sleep(0.5)

        # Apply settings in page
        driver.execute_script(f"""
            if (typeof setTheme === 'function') setTheme('{theme}');
            if (typeof setLanguage === 'function') setLanguage('{lang}');
            if (typeof setAppMode === 'function') setAppMode('{ 'incharge' if incharge else 'employee' }');
        """)
        time.sleep(0.3)

        # Test #/more
        driver.execute_script("switchPage('more', true);")
        time.sleep(0.5)
        more_active = driver.execute_script("return (document.getElementById('page-more') || {}).classList ? document.getElementById('page-more').classList.contains('active') : false;")
        assert more_active, f"page-more not active in {config_desc}"
        more_ss = os.path.join(screenshots_dir, f"step6_route_more_{config_desc}.png")
        driver.save_screenshot(more_ss)

        # Test #/team
        driver.execute_script("switchPage('team', true);")
        time.sleep(0.5)
        team_active = driver.execute_script("return (document.getElementById('page-team') || {}).classList ? document.getElementById('page-team').classList.contains('active') : false;")
        assert team_active, f"page-team not active in {config_desc}"
        team_ss = os.path.join(screenshots_dir, f"step6_route_team_{config_desc}.png")
        driver.save_screenshot(team_ss)

        # Test #/history
        driver.execute_script("switchPage('history', true);")
        time.sleep(0.5)
        hist_active = driver.execute_script("return (document.getElementById('page-history') || {}).classList ? document.getElementById('page-history').classList.contains('active') : false;")
        assert hist_active, f"page-history not active in {config_desc}"
        hist_ss = os.path.join(screenshots_dir, f"step6_route_history_{config_desc}.png")
        driver.save_screenshot(hist_ss)

        print(f"PASS: {config_desc} (more, team, history active, screenshots captured)")
        matrix_passes += 1

    # Also capture dedicated canonical screenshots for #/more, #/team, #/history
    driver.set_window_size(412, 915)
    driver.execute_script("setTheme('light'); setLanguage('en');")
    
    driver.execute_script("switchPage('more', true);")
    time.sleep(0.4)
    driver.save_screenshot(os.path.join(screenshots_dir, "step6_route_more.png"))
    
    driver.execute_script("switchPage('team', true);")
    time.sleep(0.4)
    driver.save_screenshot(os.path.join(screenshots_dir, "step6_route_team.png"))

    driver.execute_script("switchPage('history', true);")
    time.sleep(0.4)
    driver.save_screenshot(os.path.join(screenshots_dir, "step6_route_history.png"))
    
    print("\nSaved canonical screenshots: step6_route_more.png, step6_route_team.png, step6_route_history.png")

    logs = driver.get_log('browser')
    js_errs = [l for l in logs if l['level'] == 'SEVERE' and 'ERR_NAME_NOT_RESOLVED' not in l['message']]
    print(f"Total Severe JS Runtime Errors in Matrix Test: {len(js_errs)}")
    assert len(js_errs) == 0, f"Expected 0 errors, got {len(js_errs)}"

    print(f"\n==================================================")
    print(f"ALL {matrix_passes}/{total_configs} MATRIX CONFIGURATIONS PASSED!")
    print(f"==================================================")

except Exception as e:
    print(f"\nMATRIX TEST FAILED: {e}", file=sys.stderr)
    import traceback
    traceback.print_exc()
    sys.exit(1)
finally:
    driver.quit()
