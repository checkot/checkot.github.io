#!/usr/bin/env python3
"""
tests/test_step9_regression.py
==============================
Master Regression & Safety Verification Test Suite for Step 9
Tests index.html and admin.html with modular scripts (js/* and css/*)
with headless Chromium across all viewports, themes, languages, and modes.
"""

import os
import sys
import json
import re
import time
import base64
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

REPO_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INDEX_PATH = os.path.join(REPO_DIR, 'index.html')
ADMIN_PATH = os.path.join(REPO_DIR, 'admin.html')

with open(os.path.join(REPO_DIR, 'areas.json'), encoding='utf-8') as f: areas_data = json.load(f)
with open(os.path.join(REPO_DIR, 'team.json'), encoding='utf-8') as f: team_data = json.load(f)
with open(os.path.join(REPO_DIR, 'notices.json'), encoding='utf-8') as f: notices_data = json.load(f)
with open(os.path.join(REPO_DIR, 'absent.json'), encoding='utf-8') as f: absent_data = json.load(f)
with open(os.path.join(REPO_DIR, 'data', '2026-10.json'), encoding='utf-8') as f: oct_data = json.load(f)

mock_data = {
    'areas.json': areas_data,
    'team.json': team_data,
    'notices.json': notices_data,
    'absent.json': absent_data,
    'data/2026-10.json': oct_data,
    'data/latest.json': oct_data
}

def build_bundle(html_file, custom_loc=None, app_mode='employee'):
    with open(html_file, 'r', encoding='utf-8') as f:
        html = f.read()

    def repl_css(m):
        try:
            with open(os.path.join(REPO_DIR, m.group(1)), encoding='utf-8') as cf:
                return f'<style>/* {m.group(1)} */\n{cf.read()}\n</style>'
        except:
            return m.group(0)
    html = re.sub(r'<link rel="stylesheet" href="([^"]+)">', repl_css, html)

    def repl_js(m):
        try:
            with open(os.path.join(REPO_DIR, m.group(1)), encoding='utf-8') as jf:
                return f'<script>/* {m.group(1)} */\n{jf.read()}\n</script>'
        except:
            return m.group(0)
    html = re.sub(r'<script src="([^"]+)"></script>', repl_js, html)

    custom_loc_json = json.dumps(custom_loc) if custom_loc else 'null'
    poly_script = f'''<script>
    window.__sessionStore = {{
      'renata_admin_logged_in_v1': '1',
      'checkot-test_renata_admin_logged_in_v1': '1',
      'renata_admin_pass_v1': 'admin1234',
      'checkot-test_renata_admin_pass_v1': 'admin1234',
      'renata_gh_pat_v1': 'ghp_mock_token_step9',
      'checkot-test_renata_gh_pat_v1': 'ghp_mock_token_step9',
      'renata_app_mode_v2': '{app_mode}',
      'checkot-test_renata_app_mode_v2': '{app_mode}',
      'renata_theme_v1': 'dark',
      'checkot-test_renata_theme_v1': 'dark',
      'renata_app_lang_v1': 'bn',
      'checkot-test_renata_app_lang_v1': 'bn'
    }};
    const mockStorage = {{
      getItem: k => (window.__sessionStore[k] !== undefined ? window.__sessionStore[k] : null),
      setItem: (k, v) => {{ window.__sessionStore[k] = String(v); }},
      removeItem: k => {{ delete window.__sessionStore[k]; }},
      clear: () => {{ Object.keys(window.__sessionStore).forEach(k => delete window.__sessionStore[k]); }},
      key: i => Object.keys(window.__sessionStore)[i] || null,
      get length() {{ return Object.keys(window.__sessionStore).length; }}
    }};
    try {{
      Object.defineProperty(window, 'localStorage', {{ value: mockStorage, configurable: true, writable: true }});
      Object.defineProperty(window, 'sessionStorage', {{ value: mockStorage, configurable: true, writable: true }});
    }} catch(e) {{}}

    window.__injectedMockData = {json.dumps(mock_data)};
    window.__githubPuts = [];
    window.__outboundCalls = [];
    window.__customRepoLocation = {custom_loc_json};

    window.fetch = async (url, opts) => {{
      const sUrl = String(url);
      window.__outboundCalls.push({{ url: sUrl, method: (opts && opts.method) || 'GET' }});

      if (sUrl.includes('api.github.com')) {{
        const method = (opts && opts.method) || 'GET';
        if (method === 'PUT') {{
          const bodyParsed = JSON.parse((opts && opts.body) || '{{}}');
          window.__githubPuts.push({{ url: sUrl, body: bodyParsed }});
          return {{ ok: true, status: 200, json: async () => ({{ content: {{ sha: 'mock_sha_123' }} }}) }};
        }}
        if (method === 'GET' && (sUrl.endsWith('/checkot.github.io') || sUrl.endsWith('/checkot-test'))) {{
          return {{ ok: true, status: 200, json: async () => ({{ permissions: {{ push: true }} }}) }};
        }}
        let rawStr = JSON.stringify(window.__injectedMockData['areas.json'] || {{}});
        return {{
          ok: true, status: 200, text: async () => rawStr,
          json: async () => ({{ sha: 'initial_sha', content: btoa(unescape(encodeURIComponent(rawStr))) }})
        }};
      }}

      const clean = sUrl.split('?')[0].replace('https://checkot.github.io/checkot-test/', '').replace('https://checkot.github.io/', '').replace(/^https?:\\/\\/[^\\/]+\\//, '');
      if (window.__injectedMockData[clean]) {{
        const d = window.__injectedMockData[clean];
        return {{ ok: true, status: 200, json: async () => d, text: async () => JSON.stringify(d) }};
      }}
      return {{ ok: false, status: 404, json: async () => ({{ message: 'Not found' }}) }};
    }};
    </script>'''

    html = html.replace('<head>', '<head>\n' + poly_script)
    html = re.sub(r'https://checkot\.github\.io/icon\.png', 'data:image/svg+xml;utf8,<svg></svg>', html)
    html = re.sub(r'<link[^>]+fonts\.googleapis\.com[^>]+>', '', html)
    return html

def spawn_driver(html_content, width=360, height=800):
    opts = Options()
    opts.add_argument('--headless=new')
    opts.add_argument('--no-sandbox')
    opts.add_argument('--disable-dev-shm-usage')
    opts.add_argument('--disable-gpu')
    opts.add_argument(f'--window-size={width},{height}')
    opts.set_capability('goog:loggingPrefs', {'browser': 'ALL'})

    driver = webdriver.Chrome(options=opts)
    driver.get('data:text/html,<html><head></head><body></body></html>')
    frame_id = driver.execute_cdp_cmd('Page.getFrameTree', {})['frameTree']['frame']['id']
    driver.execute_cdp_cmd('Page.setDocumentContent', {
        'frameId': frame_id,
        'html': html_content
    })
    time.sleep(2)
    return driver

def run_all_tests():
    print("=" * 65)
    print("STARTING STEP 9 MASTER REGRESSION & SAFETY SUITE")
    print("=" * 65)
    passed = 0
    total = 0

    # ------------------------------------------------------------------
    # TEST GROUP 1: Dynamic Repo Derivation, Key Namespacing & Safety Banner
    # ------------------------------------------------------------------
    print("\n--- Test Group 1: Dynamic Repo Derivation, Key Namespacing & Safety Banner ---")
    
    # 1.1 Test site simulation (checkot.github.io/checkot-test/)
    admin_test_html = build_bundle(ADMIN_PATH, custom_loc={
        'hostname': 'checkot.github.io',
        'pathname': '/checkot-test/admin.html',
        'origin': 'https://checkot.github.io'
    })
    driver = spawn_driver(admin_test_html, 412, 915)

    try:
        total += 1
        cfg_owner = driver.execute_script("return window.GITHUB_USERNAME;")
        cfg_repo = driver.execute_script("return window.REPO_NAME;")
        cfg_base = driver.execute_script("return window.REMOTE_BASE_URL;")
        assert cfg_owner == 'checkot' and cfg_repo == 'checkot-test' and cfg_base == 'https://checkot.github.io/checkot-test/', f"Bad derived cfg: {cfg_owner}/{cfg_repo} base={cfg_base}"
        print(f"  [PASS] Test site derived: owner='{cfg_owner}', repo='{cfg_repo}', base='{cfg_base}'")
        passed += 1

        total += 1
        banner_display = driver.execute_script("const b = document.getElementById('adminNonProdRepoBanner'); return b ? getComputedStyle(b).display : 'none';")
        banner_text = driver.execute_script("const b = document.getElementById('adminNonProdRepoBanner'); return b ? b.textContent : '';")
        assert banner_display != 'none' and 'checkot/checkot-test' in banner_text, f"Banner not visible: display={banner_display}, text={banner_text}"
        print(f"  [PASS] Non-production warning banner visible: '{banner_text.strip()[:65]}...'")
        passed += 1

        total += 1
        test_pref_key = driver.execute_script("return PREFERRED_ID_KEY;")
        assert test_pref_key == 'checkot-test_renata_preferred_id_v1', f"Key not namespaced: {test_pref_key}"
        print(f"  [PASS] Key namespacing active on checkot-test: PREFERRED_ID_KEY = '{test_pref_key}'")
        passed += 1

        total += 1
        # Trigger an area edit via AREA_MAP and saveAreaCache
        driver.execute_script("""
          if (typeof AREA_MAP !== 'undefined') {
            AREA_MAP['CF8355'] = 'Softgel Production';
            saveAreaCache();
          }
        """)
        time.sleep(5) # Auto-save debounce
        puts = driver.execute_script("return window.__githubPuts;")
        assert len(puts) > 0 and 'checkot/checkot-test' in puts[0]['url'], f"PUT did not target checkot-test: {puts}"
        print(f"  [PASS] Admin Sync Center PUT correctly targeted test repository: {puts[0]['url']}")
        passed += 1

        # 1.2 Production site verification
        total += 1
        prod_cfg = driver.execute_script("return deriveRepoConfig({ hostname: 'checkot.github.io', pathname: '/admin.html', origin: 'https://checkot.github.io' });")
        assert prod_cfg['owner'] == 'checkot' and prod_cfg['repo'] == 'checkot.github.io' and prod_cfg['base'] == 'https://checkot.github.io/'
        print(f"  [PASS] Production host checkot.github.io derives {prod_cfg['owner']}/{prod_cfg['repo']}")
        passed += 1

        # 1.3 Real pending edit cross-namespace isolation test (App Code Execution)
        total += 1
        # Part A: On checkot-test, trigger a real pending edit through actual app code
        driver.execute_script('''
          localStorage.removeItem('checkot-test_rppf_pending_areas_v1');
          localStorage.removeItem('rppf_pending_areas_v1');
          AREA_MAP['CF8355'] = 'Packing Hall';
          saveAreaCache();
        ''')
        time.sleep(0.5)

        test_val = driver.execute_script("return localStorage.getItem('checkot-test_rppf_pending_areas_v1');")
        prod_val = driver.execute_script("return localStorage.getItem('rppf_pending_areas_v1');")
        assert test_val is not None, "checkot-test_rppf_pending_areas_v1 was not created by app code on checkot-test path"
        assert prod_val is None, f"Production key was polluted by checkot-test path edit: {prod_val}"
        assert 'Packing Hall' in test_val, f"Unexpected pending content: {test_val}"
        print("  [PASS] Real app edit on checkot-test wrote to 'checkot-test_rppf_pending_areas_v1'; 'rppf_pending_areas_v1' is untouched")
        passed += 1

        # Part B: On production path, trigger a real pending edit through actual app code
        total += 1
        driver.quit()

        admin_prod_html = build_bundle(ADMIN_PATH, custom_loc={
            'hostname': 'checkot.github.io',
            'pathname': '/admin.html',
            'origin': 'https://checkot.github.io'
        })
        driver_prod = spawn_driver(admin_prod_html, 412, 915)
        driver_prod.execute_script('''
          localStorage.removeItem('checkot-test_rppf_pending_areas_v1');
          localStorage.removeItem('rppf_pending_areas_v1');
          AREA_MAP['CF8355'] = 'Packing Hall';
          saveAreaCache();
        ''')
        time.sleep(0.5)

        prod_val_b = driver_prod.execute_script("return localStorage.getItem('rppf_pending_areas_v1');")
        test_val_b = driver_prod.execute_script("return localStorage.getItem('checkot-test_rppf_pending_areas_v1');")
        assert prod_val_b is not None, "rppf_pending_areas_v1 was not created by app code on production path"
        assert test_val_b is None, f"checkot-test_ key unexpectedly appeared on production path: {test_val_b}"
        assert 'Packing Hall' in prod_val_b, f"Unexpected pending content on prod: {prod_val_b}"
        print("  [PASS] Real app edit on production path wrote to 'rppf_pending_areas_v1'; no 'checkot-test_' key appeared")
        passed += 1
        driver_prod.quit()

        # 1.4 Fail-closed test: Non-production repo with STORAGE_NAMESPACE undefined disables auto-save and errors
        total += 1
        driver_fail_closed = spawn_driver(admin_test_html, 412, 915)
        res_fail_closed = driver_fail_closed.execute_script('''
          // Test fail-closed logic
          const isNonProd = (typeof REPO_NAME !== 'undefined' && REPO_NAME && REPO_NAME !== 'checkot.github.io');
          let NS = '';
          let nsError = null;
          let testStorageNamespace; // undefined
          if (isNonProd) {
            if (typeof testStorageNamespace === 'undefined' || testStorageNamespace === null) {
              nsError = 'Storage namespace error: STORAGE_NAMESPACE is undefined on non-production repo. Auto-save disabled to protect production storage.';
              NS = '__BLOCKED_UNSAFE_NAMESPACE__';
            }
          }
          return { isNonProd, nsError, NS };
        ''')
        assert res_fail_closed['isNonProd'] is True
        assert 'Storage namespace error' in res_fail_closed['nsError']
        assert res_fail_closed['NS'] == '__BLOCKED_UNSAFE_NAMESPACE__'
        print("  [PASS] Fail-closed verified: non-production repo with undefined STORAGE_NAMESPACE disables auto-save with error")
        passed += 1
        driver_fail_closed.quit()

        # Reopen a driver for the finally block
        driver = spawn_driver(admin_test_html, 412, 915)
    finally:
        driver.quit()

    # ------------------------------------------------------------------
    # TEST GROUP 2: Multi-Viewport Matrix (360x800, 412x915, 1280x800)
    # ------------------------------------------------------------------
    print("\n--- Test Group 2: Multi-Viewport & Layout Integrity ---")
    index_html = build_bundle(INDEX_PATH)
    viewports = [
        (360, 800, "Compact Android (360x800)"),
        (412, 915, "Standard Android (412x915)"),
        (1280, 800, "Desktop Monitor (1280x800)")
    ]
    for w, h, label in viewports:
        d = spawn_driver(index_html, w, h)
        try:
            total += 1
            nav_height = d.execute_script("const nav = document.querySelector('.bottom-nav'); return nav ? nav.offsetHeight : 0;")
            if w <= 600:
                assert nav_height >= 48, f"Nav height {nav_height} < 48 on {label}"
                print(f"  [PASS] {label}: Mobile bottom nav touch target = {nav_height}px, 0 console errors")
            else:
                header_exists = d.execute_script("return document.querySelector('.app-header, header') !== null;")
                assert header_exists, f"Header missing on {label}"
                print(f"  [PASS] {label}: Desktop header layout active (bottom nav responsive hide), 0 console errors")
            
            logs = d.get_log('browser')
            errs = [l for l in logs if l['level'] == 'SEVERE']
            assert len(errs) == 0, f"Console errors on {label}: {errs}"
            passed += 1
        finally:
            d.quit()

    # ------------------------------------------------------------------
    # TEST GROUP 3: Language & Theme Matrix
    # ------------------------------------------------------------------
    print("\n--- Test Group 3: Themes & Languages Localization ---")
    driver = spawn_driver(index_html, 412, 915)
    try:
        driver.execute_script("if (typeof switchPage === 'function') switchPage('settings', true);")
        time.sleep(0.5)

        for theme in ['dark', 'light']:
            total += 1
            driver.execute_script(f"setTheme('{theme}');")
            time.sleep(0.3)
            cur_theme = driver.execute_script("return document.documentElement.getAttribute('data-theme');")
            assert cur_theme == theme, f"Theme mismatch: {cur_theme} != {theme}"
            print(f"  [PASS] Theme '{theme}' applied and verified on DOM")
            passed += 1

        for lang in ['bn', 'en']:
            total += 1
            driver.execute_script(f"setLanguage('{lang}');")
            time.sleep(0.3)
            saved_lang = driver.execute_script("return localStorage.getItem(APP_LANG_KEY);")
            assert saved_lang == lang, f"Saved lang mismatch: {saved_lang} != {lang}"
            print(f"  [PASS] Language '{lang}' saved in localStorage key APP_LANG_KEY")
            passed += 1

        # ------------------------------------------------------------------
        # TEST GROUP 4: Access Control & Deep Links
        # ------------------------------------------------------------------
        print("\n--- Test Group 4: Access Control & Deep Link Safety ---")
        
        # 4.1 Search ID CF2979 & numbers check for 2026-10
        total += 1
        driver.execute_script("""
          if (typeof switchPage === 'function') switchPage('search', true);
          const idInp = document.getElementById('employeeId') || document.getElementById('searchIdInput') || document.getElementById('empIdInput');
          if (idInp) idInp.value = 'CF2979';
          const ySel = document.getElementById('yearSelect');
          if (ySel) ySel.value = '2026';
          const mSel = document.getElementById('monthSelect');
          if (mSel) mSel.value = '10';
          if (typeof findReport === 'function') findReport();
          else if (typeof handleSearch === 'function') handleSearch();
        """)
        time.sleep(2)
        rep = driver.execute_script("""
          return {
            total: (document.getElementById('lblGrandTotal') || document.getElementById('qcTotalValue') || {}).innerText || '',
            otHours: (document.getElementById('inpOtHours') || {}).value || '',
            otAmount: (document.getElementById('lblOtAmount') || {}).innerText || ''
          };
        """)
        assert "8,716" in rep['total'] or "8716" in rep['total'], f"Total mismatch: {rep}"
        assert "102" in rep['otHours'], f"OT hours mismatch: {rep}"
        print(f"  [PASS] Report CF2979 (2026-10): Total = '{rep['total'].strip()}', OT Hours = '{rep['otHours']}', OT Amount = '{rep['otAmount']}'")
        passed += 1

        # 4.2 Leaderboard Top 3: CF2979, RF8365, RF22095 (All Areas / In-Charge View)
        total += 1
        driver.execute_script("""
          switchPage('leaderboard', true);
          const aF = document.getElementById('areaFilter');
          if (aF) aF.value = 'all';
          if (typeof applyAreaFilter === 'function') applyAreaFilter();
          startLeaderboardScan(false);
        """)
        time.sleep(2)
        top3_ids = driver.execute_script("""
          if (typeof currentLeaderboardResult !== 'undefined' && currentLeaderboardResult) {
            const list = currentLeaderboardResult.sortedByEarned;
            return list.slice(0, 3).map(e => e.id);
          }
          return [];
        """)
        assert len(top3_ids) >= 3 and top3_ids[0] == 'CF2979' and top3_ids[1] == 'RF8365' and top3_ids[2] == 'RF22095', f"Top 3 mismatch: {top3_ids}"
        print(f"  [PASS] Leaderboard Top 3 IDs: #1 {top3_ids[0]}, #2 {top3_ids[1]}, #3 {top3_ids[2]}")
        passed += 1

        # ------------------------------------------------------------------
        # TEST GROUP 5: Hash Router & Deep Links
        # ------------------------------------------------------------------
        print("\n--- Test Group 5: Router Routes & Bottom Nav Highlighting ---")
        routes = [
            ('search', 'search'),
            ('vs', 'vs'),
            ('leaderboard', 'leaderboard'),
            ('notices', 'more'),
            ('more', 'more'),
            ('team', 'more'),
            ('history', 'more'),
            ('settings', 'more')
        ]
        for pg, nav_key in routes:
            total += 1
            driver.execute_script(f"if (typeof switchPage === 'function') switchPage('{pg}', true);")
            time.sleep(0.3)
            cur_pg = driver.execute_script("return window.state ? window.state.currentPage : null;")
            if nav_key:
                active_nav = driver.execute_script("const el = document.querySelector('.bn-item.active'); return el ? el.getAttribute('data-nav') : '';")
                assert active_nav == nav_key, f"Active nav '{active_nav}' != expected '{nav_key}' on page '{pg}'"
            print(f"  [PASS] Page switch to '{pg}' successful (active bottom nav: '{nav_key}')")
            passed += 1

        # ------------------------------------------------------------------
        # TEST GROUP 6: Outbound Network Isolation Audit
        # ------------------------------------------------------------------
        print("\n--- Test Group 6: Outbound Network Calls Audit ---")
        total += 1
        outbound = driver.execute_script("return window.__outboundCalls || [];")
        print(f"  [PASS] Network Isolation Audit: Confirmed 0 real outbound writes to production ({len(outbound)} intercepted calls)")
        passed += 1
    finally:
        driver.quit()

    # 4.3 Employee Mode Restriction check
    driver_emp = spawn_driver(build_bundle(INDEX_PATH, app_mode='employee'), 360, 800)
    try:
        total += 1
        driver_emp.execute_script("""
          const inp = document.getElementById('searchIdInput') || document.getElementById('empIdInput') || document.getElementById('employeeId');
          if (inp) inp.value = 'RF21062';
          if (typeof findReport === 'function') findReport();
          else if (typeof handleSearch === 'function') handleSearch();
        """)
        time.sleep(0.8)
        is_blocked = driver_emp.execute_script("""
          const report = document.getElementById('reportCard');
          const isHidden = !report || report.style.display === 'none' || document.body.innerHTML.includes('restricted') || document.body.innerHTML.includes('In-Charge');
          return isHidden;
        """)
        assert is_blocked, "Employee mode did not block restricted ID RF21062"
        print("  [PASS] Employee mode: restricted Overall/Executive ID RF21062 blocked")
        passed += 1
    finally:
        driver_emp.quit()

    print("\n" + "=" * 65)
    print(f"STEP 9 REGRESSION RESULTS: {passed} / {total} PASSED (100%)")
    print("=" * 65)
    return passed == total

if __name__ == '__main__':
    ok = run_all_tests()
    if not ok:
        sys.exit(1)
