# HANDOFF DOCUMENTATION — RENATA PLC OVERTIME REPORT APP (RPPF)

## 1. Project Summary
* **App Name**: RENATA PLC Overtime Report & Allowance Calculator (RPPF Production)
* **Architecture**: Fully static client-side Progressive Web App (PWA) hosted on GitHub Pages (`checkot/checkot.github.io`). Zero backend, zero database, zero build tools or npm runtime dependencies.
* **Target Audience**: Factory operators on budget Android devices (360–412 px width), operating with dusty fingers or gloves, requiring large touch targets (min 48x48 px), simple Bengali UI, and fast response times.
* **Current Status**: Steps 1–9 completed, verified, and ready for production deployment.

---

## 2. Production Deployment & Upload Guide
For deployment to GitHub Pages (`checkot/checkot.github.io` root), refer to `DEPLOY.md` (written in simple Bengali for phone-only operation).

### Production Upload List (Upload to GitHub Repo Root)
1. `index.html` — Employee app shell (~6,929 lines)
2. `admin.html` — Admin control panel shell (~2,201 lines)
3. `css/` — All modular stylesheets (`tokens.css`, `base.css`, `components.css`, `nav.css`, `pages.css`, `admin.css`)
4. `js/` — All modular scripts (`core/`, `calculations/`, `components/`, `pages/`, `admin/`)
5. `sw.js` — Service worker (version `2026-11-02-v2`, relative host registration, pure pass-through)
6. `manifest.json` — PWA manifest (scope `"./"`, start_url `"./"`)
7. `DEPLOY.md` — Phone-only deployment & rollback instructions (Termux + Git and experimental GitHub Action)
8. `.github/workflows/deploy-zip.yml` — Automated unzipping workflow for optional Method B (includes `permissions: contents: write`)

### DO NOT UPLOAD List (Keep Out of Production Repo)
* **`tests/` and `tests/fixtures/`** — Automated regression suites and baseline fixtures (`original_index.html`, `original_admin.html`). Strictly internal testing tools.
* **`screenshots/`** — Automated browser test captures and side-by-side comparison images.
* **`data/` (from this ZIP)** — Leave the existing `data/` folder in the GitHub repo untouched! The live GitHub repo's data files are updated dynamically by Python automation bots (`scripts/`) and admin uploads; do NOT overwrite them with test data.
* **`HANDOFF.md` / `CHANGELOG.md`** — Internal engineering handoff documentation (optional for repo root).
* **Live Database & Media (Leave Alone in Repo)**: `areas.json`, `team.json`, `notices.json`, `absent.json`, `team/` images, `icon.png`, `og-image.png`, `scripts/`, `.github/workflows/empress.yml`, `.github/workflows/update-notices.yml`.

---

## 3. Real-Repository Status & Pending Owner Verification
* **Sync Center Live Verification Pending**: In our environment, the Admin Sync Center (`admin-sync-bar.js`) was comprehensively tested against a simulated GitHub Contents API interceptor in `tests/test_admin.py` and `tests/test_step9_regression.py` (verifying 409 conflict 3-way merge, 401 token errors, 4-second auto-save debounce, and unsaved edit restore). **The real-repo live push test against GitHub with the owner's actual GitHub Personal Access Token (PAT) is pending deployment by the repository owner.**

---

## 4. Immutable Business Rules & Production Notes
1. **Calculation Precision**: Overtime, night, and holiday allowance calculations and rates produce 100% identical numbers to production. Past months retain their own rates.
2. **Leaderboard & Ranking Scope**: Ranking uses strictly and exclusively IDs mapped in `areas.json` (no fallback). Gender, Contractual (CF) vs Junior Officer (JO), Area, and Sub-section are sourced from `areas.json`.
3. **Leaderboard Category Filter Behaviour**: In the leaderboard, filtering by Category "CF" shows 324 rows (matching the base total), while "JO" shows 43 rows. In `applyAreaFilter()` and `deriveEmpKind()`, employees without an explicit Junior Officer / Executive grade in `areas.json` or monthly sheets default to the `CF` rate tier (`৳38/hr`) as the baseline operational workforce. Filtering by `CF` therefore retains all baseline-eligible staff (324 rows), whereas `JO` isolates the 43 employees explicitly mapped with Junior Officer grades. This is 100% existing production behaviour and is verified identical between `original_index.html` and the modular codebase.
4. **Data Precedence**: On duplicate employee IDs across uploaded Excel files, the most recently uploaded file wins.
5. **Night-Rest Credit**: +8h night-rest credit is official. The "4:30 PM day" definition stays as-is.
6. **Transparency**: All employees may see colleagues' reports, rankings, and earnings (intentional by company policy).
7. **Data Privacy**: Basic salary entered in the Payslip Estimator stays ONLY in `localStorage` under key `renata_salary_v1`. Never send to any server or file.
8. **No External Services**: Zero analytics, trackers, paid APIs, or external dependencies.
9. **Payslip PNG Export**: Verified by dimensions (`1440 × 1664` px) and non-empty valid image dataURL across both index and admin export engines.
10. **Admin Re-Optimization**: Admin "Re-optimize this month data" recalculates amounts with the CURRENT rates and can change past months' stored amounts. Do not change this behaviour; keep it identical when admin tools run.
11. **Double-Back to Exit**: The "press back again to exit" on `#/search` was tested via simulated popstate in headless Chromium, not on a physical Android device.
12. **Git Deployment Command Order**: `copy -> git add -> git commit -> git pull --rebase origin main -> git push origin main`. Rebase must occur AFTER committing local changes to prevent "cannot pull with rebase: You have unstaged changes" errors.
13. **Test Site Data Seeding**: On `checkot-test`, `REMOTE_BASE_URL` points to `https://checkot.github.io/checkot-test/`. To enable full testing of search, VS, and leaderboard on the test site, `areas.json`, `team.json`, `notices.json`, `absent.json`, and `data/2026-10.json` must be seeded into `checkot-test`. This is strictly for the test repository and never for production.
14. **LocalStorage Complete Key Namespacing**: On production (`checkot/checkot.github.io`), all keys remain completely unchanged (`renata_history_v31`, `renata_preferred_id_v1`, etc.). On any other repository host (e.g. `checkot-test`), `STORAGE_NAMESPACE` automatically prefixes all storage keys (`checkot-test_renata_...`, `checkot-test_rppf_pending_areas_v1`, `checkot-test_rppf_last_saved_ts`, `checkot-test_rppf_plant_holidays_v1`, `checkot-test_rppf_daytype_ov_v1`, `checkot-test_rppf_id_alias_v1`, `checkot-test_rppf_last_admin_sync_ts`, `checkot-test_renata_notices_read_v31`, `checkot-test_renata_cleanup_v1`, and `<head>` theme inline script) to guarantee 100% storage isolation on shared GitHub Pages domains.
15. **Fail-Closed Sync Bar Protection**: On a non-production repository where `STORAGE_NAMESPACE` is undefined or null, `admin-sync-bar.js` automatically disables auto-save, halts saving operations, and surfaces an error status in the Sync Bar to prevent any accidental write to production keys.
16. **Incognito Testing Rule**: Because GitHub Pages shares the `checkot.github.io` origin between root and sub-repos, tests on `checkot-test` should always run in an Incognito / Private browser window to ensure zero cross-contamination of cache or service workers.

---

## 5. Architectural Accomplishments (Steps 1–9)

### Step 1: Baseline Verification Harness
* Created `tests/test_runner.js` and `tests/benchmark_baseline.json` benchmarking 10 employees across all operational tiers.

### Step 2: CSS Tokens & Base Layout
* Extracted `css/tokens.css` (design tokens, dark/light themes) and `css/base.css` (resets, typography, safe-area insets). Fixed dark mode WhatsApp button contrast.

### Step 3: Components, Navigation & Layout CSS
* Extracted `css/components.css`, `css/nav.css`, and `css/pages.css`.
* Replaced erratic bottom nav scroll-hide with a permanently fixed 48x48 px touch target floor. Consolidated responsive breakpoints into 360, 600, 900, 1140 px.

### Step 4: Core & Calculations Modules
* Extracted `js/core/config.js`, `js/core/state.js`, `js/core/storage.js`, `js/core/utils.js`, `js/calculations/rates.js`, `js/calculations/ranking.js`.
* Expanded multi-month benchmark to 22 tests across 3 months (`2026-10`, `2026-03`, `2026-01` with `JO_B` ৳45 rate) and proved historical rate isolation.

### Step 5: Hash Router & Browser History Navigation
* Built `js/components/router.js` enabling deep links (`#/report?id=...&month=...`, `#/vs`, `#/leaderboard`, `#/notices`, `#/more`, `#/team`, `#/history`, `#/settings`), browser Back/Forward navigation with popstate listener, and double-back to exit on `#/search`.

### Step 6: Employee App Page Controllers (`js/pages/*`)
* Extracted `search.js`, `history.js`, `settings.js`, `report.js`, `vs.js`, `notices.js`, `more.js`, `team.js`, `leaderboard.js`.
* Built `tests/test_parity.py` (38/38 passed) verifying 100% exact parity vs `original_index.html`. Reduced `index.html` from ~15,800 to ~6,929 lines.

### Step 7: Admin Panel Modularization (`js/admin/*` & `css/admin.css`)
* Extracted `css/admin.css`, `js/admin/admin-core.js`, `js/admin/admin-github.js`, `js/admin/admin-tools.js`, and `js/admin/admin-sync-bar.js`.
* Preserved all 7 monkey-patch wrapper chains (`githubPutFile`, `githubDeleteFile`, `fetchJsonResource`, `loadAreaMap`, `saveAreaCache`, `adminPushAreasToGithub`, `adminSaveAndTestGhToken`).
* Hoisted persist shims (`persistAreaMap`, etc.) eliminating `ReferenceError`.
* Built `tests/test_admin.py` (28/28 passed) testing login, tabs, parity, and all Sync Center scenarios (auto-save debounce, 409 conflict 3-way merge, 401 token error, unsaved edit persistence). Reduced `admin.html` from ~19,059 to ~2,201 lines.

### Step 8: Service Worker, Manifest, Performance & Cleanup
* Updated `sw.js`: bumped `SW_VERSION` to `2026-11-02-v2`, verified relative URL registration in `index.html` and `admin-core.js` for multi-host resilience.
* Updated `manifest.json`: added relative scope `"./"` and start_url `"./"`.
* Deleted obsolete legacy files `indexstop.html` and `team/T.T`.
* **Slow 4G Performance Analysis (Empirical Benchmark across 3 runs)**:
  * **Monolithic Original (Step 0)**: DOMContentLoaded = 2,613.5 ms | First Report Render = 508.5 ms
  * **Modular Synchronous (Chosen Production)**: DOMContentLoaded = 3,198.3 ms | First Report Render = 345.4 ms
  * **Modular Deferred (Experimental)**: DOMContentLoaded = 2,672.0 ms | First Report Render = 389.3 ms
  * **Honest Evaluation & Trade-off**: The modular architecture has a slower initial DOMContentLoaded on Slow 4G (3,198 ms vs 2,613 ms in original) because breaking the monolithic file into modular files introduces multiple HTTP requests and TCP/TLS round-trips over high-latency connections. However, once parsed, the modular architecture achieves a significantly **faster first report render (345 ms vs 508 ms)** due to cleaner execution paths and memory indexing. Synchronous loading was selected for production to prevent race conditions with inline HTML event handlers and ensure 100% test parity.
  * **Proposed Future Optimization Options (No Code Yet)**:
    1. *Deploy-time Concatenation Script*: A simple zero-dependency Python script run at deploy time that merges modular JS/CSS files into a production bundle while maintaining modular source files for development.
    2. *Resource Preloading*: Adding `<link rel="preload" href="..." as="script">` in `<head>` for critical scripts to instruct the browser network engine to fetch all scripts concurrently during initial HTML parsing.
    3. *HTTP/2 Multiplexing*: Leveraging GitHub Pages native HTTP/2 to stream parallel asset requests over a single TCP connection.
* Authored `DEPLOY.md` in simple Bengali covering Termux + Git (Method A) and GitHub Action ZIP deploy (Method B).

### Step 9: Test Repository Safety, Complete Namespacing & Master Regression Suite
* **Dynamic Repository Derivation (`deriveRepoConfig`)**:
  - Dynamically extracts repository owner, repo name, and remote base URL from `window.location` in `js/core/config.js` and `js/admin/admin-core.js`.
  - On `checkot.github.io/checkot-test/`, targets `checkot/checkot-test` with base `https://checkot.github.io/checkot-test/`.
  - On `checkot.github.io` or `localhost`, defaults safely to `checkot/checkot.github.io` and `https://checkot.github.io/`.
* **Complete Storage Key Namespacing (`STORAGE_NAMESPACE`)**:
  - Namespaces ALL keys and cache prefixes across the entire app (`rppf_plant_holidays_v1`, `rppf_daytype_ov_v1`, `rppf_id_alias_v1`, `rppf_last_admin_sync_ts`, `renata_notices_read_v31`, `renata_cleanup_v1`, and `<head>` theme script).
  - Production keys remain 100% unchanged.
* **Fail-Closed Auto-Save Protection**:
  - On non-production repos where `STORAGE_NAMESPACE` is undefined, `admin-sync-bar.js` disables auto-save, blocks saves, and surfaces an error message in the status bar rather than falling back to `''`.
* **Admin Safety Warning Banner**:
  - Prominent yellow warning banner (`#adminNonProdRepoBanner`) displayed at the top of `#adminDashboardWrap` and `#adminLoginCard` whenever active repository is not production.
* **Test Site Fallback Resilience**:
  - When `areas.json` or monthly data files are missing on `checkot-test/`, fetches fail gracefully with a 404 and safely fall back to local cache or `DEFAULT_FALLBACK_AREAS`.
  - Sync Center writes directly to `api.github.com/repos/checkot/checkot-test/contents/areas.json` without modifying production.
* **Master Step 9 Regression Suite (`tests/test_step9_regression.py`)**:
  - **Tool & Runtime**: Executed via **Python 3 (`python3`) with the `selenium` package driving headless Chromium (`--headless=new`)**.
  - **Reconciled Test Definitions**:
    - **Full Regression Test Bed (243 Total Assertions)**:
      1. `tests/test_router_matrix.py`: **128 element assertions** across 4 orthogonal configurations (32 checks per configuration across 6 traversed routes).
      2. `tests/test_parity.py`: **38 baseline functional parity assertions** against Step 0 `original_index.html`.
      3. `tests/test_admin.py`: **28 admin panel & sync bar assertions** against Step 0 `original_admin.html`.
      4. `tests/test_runner.js`: **22 multi-month calculation invariance assertions**.
      5. `tests/test_router.py`: **27 individual assertion checks** across deep linking, refresh, popstate history, and double-back exit toast (reported as 13 grouped result items in its final summary table).
    - **Single Master Suite (`tests/test_step9_regression.py` - 27 Milestones)**:
      1. `test_dynamic_repo_derivation_test_site` (`checkot/checkot-test`)
      2. `test_non_prod_safety_banner_visible` (`#adminNonProdRepoBanner`)
      3. `test_key_namespacing_active_on_test_repo` (`checkot-test_renata_preferred_id_v1`)
      4. `test_admin_sync_put_target_isolation` (`checkot-test`)
      5. `test_dynamic_repo_derivation_production` (`checkot/checkot.github.io`)
      6. `test_real_app_edit_isolation_checkot_test` (App code writes `checkot-test_rppf_pending_areas_v1`, production key untouched)
      7. `test_real_app_edit_isolation_production` (App code writes `rppf_pending_areas_v1`, no `checkot-test_` key appears)
      8. `test_fail_closed_undefined_namespace_non_prod` (Disables auto-save and errors on undefined namespace)
      9. `test_viewport_compact_android_360x800` (65px >= 48px, 0 errors)
      10. `test_viewport_standard_android_412x915` (65px >= 48px, 0 errors)
      11. `test_viewport_desktop_monitor_1280x800` (header layout active, 0 errors)
      12. `test_theme_dark_mode_applied` (`data-theme="dark"`)
      13. `test_theme_light_mode_applied` (`data-theme="light"`)
      14. `test_language_bengali_persisted` (`renata_app_lang_v1="bn"`)
      15. `test_language_english_persisted` (`renata_app_lang_v1="en"`)
      16. `test_report_cf2979_numbers_oct_2026` (Total ৳ 8,716.00, OT 102h, OT Amount ৳ 3,876.00)
      17. `test_leaderboard_top3_ranking_oct_2026` (#1 CF2979, #2 RF8365, #3 RF22095)
      18–25. Router routes and bottom nav highlighting (search, vs, leaderboard, notices, more, team, history, settings)
      26. `test_network_isolation_audit` (zero real external calls)
      27. `test_employee_mode_rf21062_restricted` (Executive/Overall area restriction)

---

## 6. Master Test Suite Commands
* **Calculation regression suite (22 tests)**: `node tests/test_runner.js`
* **Router & browser history suite (13 test results / 27 assertions)**: `python3 tests/test_router.py`
* **Extended router matrix suite (4 orthogonal configs / 128 assertions)**: `python3 tests/test_router_matrix.py`
* **Employee app functional parity suite (38 tests)**: `python3 tests/test_parity.py`
* **Admin panel & Sync Center suite (28 tests)**: `python3 tests/test_admin.py`
* **Step 9 Master regression & safety suite (27 tests)**: `python3 tests/test_step9_regression.py` *(requires Python 3 and Selenium with Chromium)*

---

## 7. Final File Map
```
.
├── DEPLOY.md                  # Bengali phone-only deployment & rollback guide (Termux + Actions)
├── HANDOFF.md                 # Master technical handoff documentation
├── CHANGELOG.md               # Versioned engineering changelog
├── index.html                 # Modular employee app shell (~6,929 lines)
├── admin.html                 # Modular admin control panel shell (~2,201 lines)
├── granulation.html           # Standalone granulation calculator
├── manifest.json              # PWA manifest (scope: "./", start_url: "./")
├── sw.js                      # Pure network pass-through service worker (v2)
├── areas.json                 # Employee area & rate directory
├── team.json                  # Team directory data
├── notices.json               # Notice board data
├── absent.json                # Absent & leave store
├── icon.png                   # App icon
├── og-image.png               # Social preview card
├── .github/
│   └── workflows/
│       ├── empress.yml        # Automated Empress bot
│       ├── update-notices.yml # Automated notices bot
│       └── deploy-zip.yml     # Experimental automated ZIP deploy workflow (with contents: write)
├── css/
│   ├── tokens.css             # Design tokens & color variables
│   ├── base.css               # Resets, typography, safe-area insets
│   ├── components.css         # UI components & touch targets
│   ├── nav.css                # Fixed bottom nav & header
│   ├── pages.css              # Page view layouts & desktop grids
│   └── admin.css              # Comprehensive admin panel stylesheet
├── js/
│   ├── core/                  # config.js, state.js, storage.js, utils.js
│   ├── calculations/          # rates.js, ranking.js
│   ├── components/            # router.js
│   ├── pages/                 # search, history, settings, report, vs, notices, more, team, leaderboard
│   └── admin/                 # admin-core, admin-github, admin-tools, admin-sync-bar
├── data/                      # Historical monthly JSON datasets
└── tests/                     # Test runners, parity benchmarks, regression suites, and fixtures
```
