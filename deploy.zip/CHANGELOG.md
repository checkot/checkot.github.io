# CHANGELOG

## [Step 9] - 2026-11-02
### Added
- **Complete Storage Key Namespacing (`STORAGE_NAMESPACE`)**:
  - Dynamically isolates all `localStorage` keys and prefixes when running on non-production repositories (such as `checkot-test`).
  - Namespaces `rppf_plant_holidays_v1`, `rppf_daytype_ov_v1`, `rppf_id_alias_v1`, `rppf_last_admin_sync_ts`, `renata_notices_read_v31`, `renata_cleanup_v1`, and the `<head>` inline theme script prefix.
  - On production (`checkot/checkot.github.io`), `STORAGE_NAMESPACE` is strictly empty `""`, leaving all keys completely unchanged.
- **Fail-Closed Auto-Save Protection**:
  - In `js/admin/admin-sync-bar.js`, on a non-production repository where `STORAGE_NAMESPACE` is undefined or null, auto-save is automatically disabled and an error is displayed in the Sync bar, completely preventing any fallback to un-namespaced keys (`''`).
- **Real App-Code Isolation Verification**:
  - Replaced literal key comparisons in `tests/test_step9_regression.py` with real app-code operations:
    - Executing `saveAreaCache()` on `checkot-test` writes exclusively to `checkot-test_rppf_pending_areas_v1` while leaving `rppf_pending_areas_v1` untouched.
    - Executing `saveAreaCache()` on production writes exclusively to `rppf_pending_areas_v1` with zero `checkot-test_` keys appearing.
    - Tested fail-closed behavior when `STORAGE_NAMESPACE` is undefined on a non-production repository.
- **Master Regression & Safety Suite (`tests/test_step9_regression.py`)**:
  - Executed via **Python 3 (`python3`) with the `selenium` package driving headless Chromium (`--headless=new`)**.
  - 27 distinct verifiable test milestones passed (100%).

### Changed
- **`DEPLOY.md`**:
  - Rewritten in simple Bengali for phone-only operation following exact safe sequence:
    1. Test repo `checkot-test` creation with "Add a README file" checked first.
    2. Fine-grained 30-day token creation explicitly selecting both repos (`checkot.github.io` and `checkot-test`).
    3. Git identity configuration (`user.name` and `user.email`) before first commit.
    4. Test site data seeding step: Copies `areas.json`, `team.json`, `notices.json`, `absent.json`, and `data/2026-10.json` from production clone into `checkot-test` so all 8 checklist tests pass, explicitly restricted to test repo only.
    5. Correct git command sequence: `copy -> git add -> git commit -> git pull --rebase origin main -> git push origin main` ensuring no "unstaged changes" errors during rebase.
    6. Added Incognito / Private browsing window note to test checklist and instructions.
    7. Explicit item-by-item copy commands, strictly prohibiting `cp -r .../* .`.
    8. Clean `git add` omitting `.github/` and strictly warning: "never use git add . or git commit -a".
    9. Token cleanup updated to reference step 8, with clear notice that future rollbacks require re-authenticating with the token.
    10. 8-point Android test checklist with item 8 highlighting the test warning banner and noting test admin writes safely to `checkot-test`.
- **`.github/workflows/deploy-zip.yml`**:
  - Restored `permissions: contents: write` at the job level to ensure automated commit push succeeds without 403 errors.
  - Safely deletes `deploy.zip` using `git rm -f --ignore-unmatch deploy.zip`.
  - Enforced strict whitelist copy and forbidden path checks (`data/`, `scripts/`, `.github/`, `areas.json`, etc.).
  - Removed `[skip ci]` so GitHub Pages publish workflow triggers reliably.
  - Added copy output listing and documented root-level zip requirement for Method B.

### Reconciled Test Verification
- **Full Test Bed Assertions**: **243 assertions** (`tests/test_router_matrix.py`: 128 UI element checks; `tests/test_parity.py`: 38 baseline parity checks; `tests/test_admin.py`: 28 sync and tab checks; `tests/test_runner.js`: 22 multi-month calculation checks; `tests/test_router.py`: 27 routing/history checks).
- **Master Regression Suite (`tests/test_step9_regression.py`)**: **27/27 passed** in headless Chromium.

## [Step 8] - 2026-11-02
### Added
- `DEPLOY.md`: Initial deployment guide in Bengali for phone-only operation.
- `.github/workflows/deploy-zip.yml`: Experimental automated ZIP deployment workflow.
- Manifest updates: Configured relative `"scope": "./"` and `"start_url": "./"` in `manifest.json`.
- Bumped `SW_VERSION` in `sw.js` to `2026-11-02-v2`.
- Slow 4G performance analysis: Measured DOMContentLoaded and First Report Render across monolithic vs modular architectures.
